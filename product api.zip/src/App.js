import { useState } from 'react';
import './App.css';
import Product from './components/Product';
import ProductClass from './components/ProductClass';



function App() {
  const [isClassComponent , setIsClassComponent] = useState(true);

  const toggleComponent = ()=>{
    setIsClassComponent(!isClassComponent);
  };

  return (
    <div className="App">
     <>
     {isClassComponent?(
      <ProductClass />
      ) :(
      <Product />
      )    
    }
     <div>

    <button type="button" class="btn btn-primary" onClick={toggleComponent}>Switch Component</button>
     </div>

     </>

    </div>
  );
}

export default App;
