

function Loader() {
  return (
    <div>Loader</div>
  )
}

export default Loader