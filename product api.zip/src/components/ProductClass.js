import React , {Component} from "react";
import axios from "axios";


export class ProductClass extends Component {
  constructor(){
    super();
    this.state ={
        product :"",
        data :""
    }
  }

  componentDidUpdate = async (x,y)=>{
    if(y.product !== this.state.product){
        const res = await axios.get(`https://dummyjson.com/products/${this.state.product}`)
        this.setState(
            {data: res.data}
        )
    }
  }

handleChangeData = () =>{
    this.setState({
        product: Math.floor(Math.random()*100)+1
    })
}


  render() {
    return (
      <>

{/*        
     <section class="h-100" style={{backgroundColor: "#eee;"}}>
  <div class="container h-100 py-5">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-10">
               <h2>  function based</h2>
        <div class="card rounded-3 mb-4">
          <div class="card-body p-4">
            <div class="row d-flex justify-content-between align-items-center">
              <div class="col-md-2 col-lg-2 col-xl-2">
                 {this.state.data ?   <img
                  src={this.state.data.thumbnail}
                  className="img-fluid rounded-3" alt="Cotton T-shirt"/>
                  :<h2> There is nothing to show image</h2>}
              </div>
              <div class="col-md-3 col-lg-3 col-xl-3">
        {this.state.data?  <p class="lead fw-normal mb-2">{this.state.data.title}</p>
                : <p> There is nothing to show </p>}
            {this.state.data?  
                <p><span class="text-muted">{this.state.data.brand}</span><span class="text-muted"></span></p>
                : <h1>There is nothing to show brand</h1> }
              </div>
              <div class="col-md-3 col-lg-3 col-xl-2 d-flex">
                <button class="btn btn-link px-2"
                  onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                  <i class="fas fa-minus"></i>
                </button>

                <button class="btn btn-link px-2"
                  onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                  <i class="fas fa-plus"></i>
                </button>
              </div>
              <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                {this.state.data? <h5 class="mb-0">{this.state.data.price}</h5>:  <h5>do you wanna see price</h5> }
              </div>
              <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                <a href="#!" class="text-danger"><i class="fas fa-trash fa-lg"></i></a>
              </div>
            </div>
          </div>
        </div>
       

        <div class="card">
          <div class="card-body">
            <button type="button" class="btn btn-warning btn-block btn-lg" onClick={this.handleChangeData}>Change Data</button>
          </div>
        </div>

      </div>
    </div>
  </div>
</section> */}

<section style={{backgroundColor: "#eee;"}}>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6 col-xl-4">
        <div class="card text-black">
          <i class="fab fa-apple fa-lg pt-3 pb-1 px-3"></i>
         {this.state.data ?<img
         src={this.state.data.thumbnail}
            class="card-img-top"
            alt="Apple Computer"
          />: <h1> oops, i want see your image</h1>}
          <div class="card-body">
            <div class="text-center">
                 {this.state.data?  <p class="card-title">{this.state.data.title}</p>
                : <p> There is nothing to show </p>}
           
               {this.state.data?  
                <p><span class="text-muted mb-4">{this.state.data.brand}</span><span class="text-muted"></span></p>
                : <h1>There is nothing to show brand</h1> }
            </div>
            
           
           
            <div  class="d-flex justify-content-between total font-weight-bold mt-4">
               
              <span>Total</span>
                {this.state.data?
                <span>${this.state.data.price}</span>
              :<h1>no price</h1> }
            </div>
             
             <div class="card">
          <div class="card-body">
            <button type="button" class="btn btn-warning btn-block btn-lg" onClick={this.handleChangeData}>Change Data</button>
          </div>
        </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

      
      </>
    )
  }
}

export default ProductClass